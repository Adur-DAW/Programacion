
/**
 * Write a description of class NumeroCombinatorio here.
 * 
 * @author Adur Marques
 * @version (a version number or a date)
 */
public class NumeroCombinatorio
{
    // instance variables - replace the example below with your own
    private int n;
    
    private int m;

    /**
     * Constructor for objects of class NumeroCombinatorio
     */
    public NumeroCombinatorio()
    {
    }
    
    /**
     * No me ha dado tiempo
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    private int factorial(int factorial)
    {
        return factorial;
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public int getN()
    {
        return n;
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void setN(int n)
    {
        this.n = n;
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public int getM()
    {
        return m;
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void setM(int m)
    {
        this.m = m;
    }
    

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public int obtenerCombinatorio()
    {
        return 1;
    }
}
