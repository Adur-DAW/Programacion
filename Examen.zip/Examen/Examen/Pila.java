import java.util.Arrays;

/**
 * Clase Pila
 * 
 * @author Adur Marques Herrero
 * @version 1.0.0
 */
public class Pila
{
    private Entero[] elementos;
    private int top;
    
    /**
     * Constructor para los elementos de la clase Pila
     */
    public Pila(int cantidadElementos)
    {
        this.top = 0;

        for(int i=0; i < cantidadElementos; i++)
        {
            push(new Entero(0));
        }
    }

    /**
     * Indica si la pila está o no vacía
     * 
     * @param
     * @return True o False dependiendo si la lista está vacía o no
     */
    public boolean estaVacia()
    {
        return (elementos.length == 0);
    }
    
    /**
     * Indica si la pila está o no llena
     * 
     * @param
     * @return True o False dependiendo si la lista está llena o no
     */
    public boolean estaLlena()
    {
        if (elementos == null) return false;
        
        return (top == elementos.length - 1);
    }
    
    /**
     * Devuelve el objeto que está en la cumbre sin modificar la pila
     * 
     * @param
     * @return Objeto que está en la cumbre
     */
    public int getCumbre()
    {
        if (estaVacia())
        {
            System.out.println("Pila vacía");
            
            // No me deja devolver null
            return 0;
        }
        
        return elementos[elementos.length - 1].getValor();
    }
    
    /**
     * Saca de la pila el elemento apuntado por la cumbre y lo devuelve
     * 
     * @param
     * @return Elemento eliminado
     */
    public int pop()
    {
        if (estaVacia())
        {
            System.out.println("Pila vacía");
            
            // No me deja devolver null
            return 0;
        }
        
        top--;
        
        int elementoBorrado = getCumbre();
        
        for (int i = 0; i < elementos.length - 1; i++) {
            elementos[i] = elementos[i + 1];
        }

        elementos = new Entero[elementos.length - 1];
        
        return elementoBorrado;
    }
    
    /**
     * Añade un nuevo elemento a la pila lo que supone una cambio de estado de la pila
     * 
     * @param Nuevo valor INT a añadir al array elementos
     * @return
     */
    public void push(Entero valor)
    {
       if (estaLlena())
       {
            System.out.println("Pila llena");
            return;
       }
       
       top++;
       
       if (elementos == null)
       {
           elementos = new Entero[1];
           
           elementos[0] = valor;
       }
       else
       {
           Entero[] nuevaLista = Arrays.copyOf(elementos, elementos.length+1);
           nuevaLista[elementos.length] = valor;
           
           elementos = nuevaLista;
       }
    }
    
    /**
     * Devuelve el array de Entero
     * 
     * @param
     * @return array de Entero
     */
    public Entero[] consultarElementos()
    {
        return elementos;
    }
}
